# Overview

PlanktonPy is a 0D plankton ecosystem model in Python.

## Documentation
https://planktopy.readthedocs.io/en/latest/#