# Overview

PlanktonPy is a 0D dimensional plankton ecosystem model in Python.

